#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <iostream>
#include <fstream>
#include <queue>
#include <unordered_map>
#include <vector>
#include <sstream>
using namespace std;

void searchAlumniByDomain(string domain);
void sendMentorshipRequest(string studentEmail, string alumniEmail);
void viewRequests();
void giveFeedback(string from, string to);

#endif
