#ifndef USER_H
#define USER_H
#include <iostream>
#include <string>
using namespace std;

class User {
protected:
    string name, email, password;
public:
    virtual void registerUser() = 0;
    virtual bool loginUser(string email, string password) = 0;
};

#endif
