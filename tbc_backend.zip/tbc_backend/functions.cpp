#include "functions.h"

void searchAlumniByDomain(string domain) {
    ifstream file("data/alumni.txt");
    string name, email, pass, dom, comp, year;
    bool found = false;

    cout << "\n--- Alumni Matching Domain: " << domain << " ---\n";
    while (getline(file, name, ',') && getline(file, email, ',') && getline(file, pass, ',') &&
           getline(file, dom, ',') && getline(file, comp, ',') && getline(file, year)) {
        if (dom == domain) {
            found = true;
            cout << "Name: " << name << "\nEmail: " << email << "\nCompany: " << comp << "\nYear: " << year << "\n\n";
        }
    }
    if (!found) cout << "No alumni found for this domain.\n";
}

void sendMentorshipRequest(string studentEmail, string alumniEmail) {
    ofstream file("data/requests.txt", ios::app);
    file << studentEmail << "->" << alumniEmail << "\n";
    file.close();
    cout << "Mentorship request sent!\n";
}

void viewRequests() {
    ifstream file("data/requests.txt");
    string line;
    priority_queue<string, vector<string>, greater<string>> pq; // lexicographically smaller first

    while (getline(file, line))
        pq.push(line);

    cout << "\n--- Pending Mentorship Requests ---\n";
    while (!pq.empty()) {
        cout << pq.top() << endl;
        pq.pop();
    }
}

void giveFeedback(string from, string to) {
    string rating, comment;
    cout << "Enter Rating (1–5): ";
    getline(cin, rating);
    cout << "Enter Feedback Comment: ";
    getline(cin, comment);

    ofstream file("data/feedback.txt", ios::app);
    file << from << "->" << to << "," << rating << "," << comment << "\n";
    file.close();
    cout << "Feedback recorded successfully!\n";
}
