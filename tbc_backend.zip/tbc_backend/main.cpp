#include "student.h"
#include "alumni.h"
#include "functions.h"

int main() {
    int choice;
    while (true) {
        cout << "\n===== STUDENT ALUMNI MENTORING PLATFORM =====\n";
        cout << "1. Student Registration\n2. Alumni Registration\n3. Student Login\n4. Alumni Login\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            Student s; s.registerUser();
        } 
        else if (choice == 2) {
            Alumni a; a.registerUser();
        } 
        else if (choice == 3) {
            string email, password;
            cout << "Enter Email: "; getline(cin, email);
            cout << "Enter Password: "; getline(cin, password);
            Student s;
            if (s.loginUser(email, password)) {
                cout << "Login successful!\n";
                int opt;
                do {
                    cout << "\n--- Student Menu ---\n1. Search Alumni by Domain\n2. Send Mentorship Request\n3. Give Feedback\n4. Logout\n";
                    cout << "Choice: "; cin >> opt; cin.ignore();
                    if (opt == 1) {
                        string domain;
                        cout << "Enter Domain: "; getline(cin, domain);
                        searchAlumniByDomain(domain);
                    } 
                    else if (opt == 2) {
                        string alumEmail;
                        cout << "Enter Alumni Email: "; getline(cin, alumEmail);
                        sendMentorshipRequest(email, alumEmail);
                    } 
                    else if (opt == 3) {
                        string to;
                        cout << "Enter Alumni Email for Feedback: "; getline(cin, to);
                        giveFeedback(email, to);
                    }
                } while (opt != 4);
            } else cout << "Invalid login.\n";
        } 
        else if (choice == 4) {
            string email, password;
            cout << "Enter Email: "; getline(cin, email);
            cout << "Enter Password: "; getline(cin, password);
            Alumni a;
            if (a.loginUser(email, password)) {
                cout << "Login successful!\n";
                int opt;
                do {
                    cout << "\n--- Alumni Menu ---\n1. View Mentorship Requests\n2. Logout\n";
                    cout << "Choice: "; cin >> opt; cin.ignore();
                    if (opt == 1) viewRequests();
                } while (opt != 2);
            } else cout << "Invalid login.\n";
        } 
        else if (choice == 5) break;
    }
    return 0;
}
